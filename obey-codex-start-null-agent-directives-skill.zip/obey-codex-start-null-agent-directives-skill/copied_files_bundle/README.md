# Copied Files Bundle

This folder contains copied files requested for review.

## Included
- Repository files: `AGENTS.md`, `ROLE.md`
- Skill files:
  - `skills/skill-creator.SKILL.md`
  - `skills/skill-installer.SKILL.md`

## Workflow files
- No workflow files were found in this repository, so `workflows/` is currently empty.
